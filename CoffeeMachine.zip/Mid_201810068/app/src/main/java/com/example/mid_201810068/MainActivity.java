package com.example.mid_201810068;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private int CoffeeCost = 1000, SizeCost = 0; // 커피 비용과 사이즈 비용
    private TextView VisableCost;
    RadioGroup CoffeeGroup, SizeGroup;      // 커피그룹과 사이즈그룹
    RadioButton Americano, Cafferatte, Caffucino;   // 커피 종류 세 가지(아메리카노, 카페라떼, 카푸치노)
    RadioButton Small, Medium, Large;   // 사이즈 세 가지(작은, 중간, 큰)
    Button Calculator;              // 계산 이벤트 처리해주는 버튼
    TextView Charge;                // 계산된 가격이 나타나는 텍스트뷰
    ImageView image;

    View.OnClickListener SelectedCoffee = new View.OnClickListener(){
        @Override
        public void onClick(View v){
            switch(CoffeeGroup.getCheckedRadioButtonId()) {      // 커피 그룹의 체크된 RadioButton 가져옴
                case R.id.Americano:
                    CoffeeCost = 1000;
                    image.setImageResource(R.drawable.aamericano);
                    Checked("아메리카노");
                    break;
                case R.id.Cafferatte:
                    CoffeeCost = 1500;
                    image.setImageResource(R.drawable.ccaferatte);
                    Checked("카페라떼");
                    break;
                case R.id.Caffucino:
                    CoffeeCost = 2000;
                    image.setImageResource(R.drawable.ccafficino);
                    Checked("카푸치노");
                    break;
            }
        }
    };
    View.OnClickListener SelectedSize = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            switch (SizeGroup.getCheckedRadioButtonId()) {      // 사이즈 그룹의 체크된 RadioButton 가져옴
                case R.id.Small:
                    SizeCost = 0;
                    Checked("SMALL");
                    break;
                case R.id.Medium:
                    SizeCost = 500;
                    Checked("MEDIUM");
                    break;
                case R.id.Large:
                    SizeCost = 1000;
                    Checked("LARGE");
                    break;
            }
        }
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("커피 자판기");

        // 초기화
        VisableCost = (TextView)findViewById(R.id.Charge);
        VisableCost.setText("0");

        CoffeeGroup = (RadioGroup)findViewById(R.id.RadioGroup1);
        Americano = (RadioButton)findViewById(R.id.Americano);
        Cafferatte = (RadioButton)findViewById(R.id.Cafferatte);
        Caffucino = (RadioButton)findViewById(R.id.Caffucino);

        SizeGroup = (RadioGroup)findViewById(R.id.RadioGroup2);
        Small = (RadioButton)findViewById(R.id.Small);
        Medium = (RadioButton)findViewById(R.id.Medium);
        Large = (RadioButton)findViewById(R.id.Large);

        Calculator = (Button)findViewById(R.id.Calculator);

        Charge = (TextView)findViewById(R.id.Charge);

        image = (ImageView)findViewById(R.id.imageView);

        // 이벤트 리스너 1 달기
        Americano.setOnClickListener(SelectedCoffee);
        Cafferatte.setOnClickListener(SelectedCoffee);
        Caffucino.setOnClickListener(SelectedCoffee);
        // 이벤트 리스너 2 달기
        Small.setOnClickListener(SelectedSize);
        Medium.setOnClickListener(SelectedSize);
        Large.setOnClickListener(SelectedSize);

        // 리스너를 다르게 해준 이유
        // 같은 리스너를 사용하고 같은 Checked 함수를 사용하니
        // Coffee그룹과 Size그룹 둘 중 하나의 토스트메시지가 씹힌다.


        // &알게 된 것
        // 토스트로 문장을 띄우는 것은 OnClick내부에서 정의가 불가, 메서드를 이용해야했음.


    }

    public void Btn_Clicked(View view){
        VisableCost.setText(Integer.toString(CoffeeCost + SizeCost));
    }
    public void Checked(String str){
        Toast.makeText(this, str + " 선택" , Toast.LENGTH_SHORT).show();
    }
}
