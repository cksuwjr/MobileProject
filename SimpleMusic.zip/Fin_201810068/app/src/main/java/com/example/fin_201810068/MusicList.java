package com.example.fin_201810068;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class MusicList extends AppCompatActivity {
    ListView list;
    String[] urls = {
            "https://www.youtube.com/watch?v=47Vz-ptyKbQ",
            "https://www.youtube.com/watch?v=UC5pmyVJ4t4",
            "https://www.youtube.com/watch?v=BrFBdIkK99Y",
            "https://www.youtube.com/watch?v=pTD9Jysi3_g",
            "https://www.youtube.com/watch?v=CyFrK4tL-SM",
            "https://www.youtube.com/watch?v=s6RKZrjzjLY",
            "https://www.youtube.com/watch?v=_78JiWS6fUA",
            "https://www.youtube.com/watch?v=z2oAKjM-gGM"
    };
    String[] titles = {
            "술이 달다",
            "Here Come the Regret",
            "연애소설",
            "빈차",
            "춥다",
            "우산",
            "헤픈엔딩",
            "AMOR FATI"

    } ;
    Integer[] images = {
            R.drawable.sweetalcol,
            R.drawable.hregret,
            R.drawable.lovestory,
            R.drawable.emptycar,
            R.drawable.itsocold,
            R.drawable.umbrella,
            R.drawable.heapen,
            R.drawable.amorpati,
    };
    String[] Album = {
            "sleepless in __________",
            "WE'VE DONE SOMETHING WONDERFUL",
            "WE'VE DONE SOMETHING WONDERFUL",
            "WE'VE DONE SOMETHING WONDERFUL",
            "99",
            "Pieces, Part One",
            "신발장",
            "신발장"

    };
    String[] featured = {
            "Feat.Crush",
            "Feat.이하이",
            "Feat.아이유",
            "Feat.오혁",
            "Feat.이하이",
            "Feat.윤하",
            "Feat.조원선 of 롤러코스터",
            "Feat.김종완 of 넬"

    };
    String[] release_year = {
            "2019.03.11",
            "2017.10.23",
            "2017.10.23",
            "2017.10.23",
            "2012.10.19",
            "2008.04.17",
            "2014.10.21",
            "2014.10.21 "
    };
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.musiclist);
        this.setTitle("Epik high 음악 듣기");
        CustomList adapter = new
                CustomList(MusicList.this);
        list=(ListView)findViewById(R.id.list);
        list.setAdapter(adapter);
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {

                Toast.makeText(getBaseContext(), titles[+position], Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(getApplicationContext(), Watching.class);
                intent.putExtra("URL", urls[+position]);
                startActivity(intent);

            }
        });
    }
    public class CustomList extends ArrayAdapter<String> {
        private final Activity context;
        public CustomList(Activity context ) {
            super(context, R.layout.list_item, titles);
            this.context = context;
        }
        @Override
        public View getView(int position, View view, ViewGroup parent) {
            LayoutInflater inflater = context.getLayoutInflater();
            View rowView= inflater.inflate(R.layout.list_item, null, true);
            ImageView imageView = (ImageView) rowView.findViewById(R.id.image);
            TextView title = (TextView) rowView.findViewById(R.id.title);
            TextView featuring = (TextView) rowView.findViewById(R.id.rating);
            TextView genre = (TextView) rowView.findViewById(R.id.genre);
            TextView year = (TextView) rowView.findViewById(R.id.releaseYear);

            title.setText(" " + titles[position]);
            imageView.setImageResource(images[position]);
            featuring.setText("   " + featured[position]);
            genre.setText(" Album: " + Album[position]);
            year.setText(" " + release_year[position]);
            return rowView;
        }
    }
}
