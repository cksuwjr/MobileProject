package com.example.fin_201810068;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {

    private WebView webView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        this.setTitle("Made for listening songs by Epik High");

    }

    public void MusicList(View view) { // 첫번째 버튼 클릭시 호출
        Intent intent = new Intent(getApplicationContext(), MusicList.class);
        startActivity(intent);
    }

    public void visitsite(View view) {
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/user/OfficialEpikHigh"));
        startActivity(intent);
    }
}
